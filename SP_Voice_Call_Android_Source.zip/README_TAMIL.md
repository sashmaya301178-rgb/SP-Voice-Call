# SP Voice Call — Android Native Kotlin

## இந்த Project-ல் உள்ளவை
- Android `CallScreeningService` மூலம் incoming call screening
- இந்திய 140 தொடக்க எண்களைத் தடுக்க அடிப்படை விதி
- Contacts-ல் இல்லாத எண்களைத் தடுக்கும் ON/OFF அமைப்பு
- பயனர் கைமுறையாக Spam எண்களைச் சேர்க்கும் பட்டியல்
- Blocked / Allowed அழைப்புப் பதிவு
- Tamil Text-to-Speech குரல் சோதனை
- GitHub Actions APK build workflow

## வரம்புகள் / பாதுகாப்பு
- 140 எண்ணைத் தொடங்கும் எல்லா அழைப்புகளும் மோசடி என்று பொருள் அல்ல; இந்த project அவற்றை telemarketing எனக் கருதி block செய்கிறது.
- Fraud / unverified spam detection-க்கு நம்பகமான spam database அல்லது caller identification சேவை தேவை. இந்த offline project எல்லா spam-ஐ 100% கண்டறியாது.
- Android CallScreening role-ஐ பயனர் அமைப்பில் அனுமதிக்க வேண்டும்.
- Unknown-number blocking ON செய்தால் Contacts-ல் இல்லாத முக்கியமான அழைப்புகளும் தடுக்கப்படலாம்.
- TTS feature என்பது தமிழில் voice test மட்டுமே. இது SIM அழைப்பை AI எடுத்துப் பேசுவதில்லை.
- Call screening கிடைக்கும் Android 10+ சாதனங்களை நோக்கி அமைக்கப்பட்டுள்ளது.

## Android Studio மூலம் APK
1. Android Studio-வில் **Open** தேர்வு செய்து project folder-ஐத் திறக்கவும்.
2. Gradle Sync முடிக்கவும்.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions மூலம் APK
1. இந்த project-ஐ GitHub repository-க்கு upload செய்யவும்.
2. Actions tab-ல் **Build SP Voice Call APK** workflow தேர்வு செய்யவும்.
3. **Run workflow** அழுத்தவும்.
4. Workflow முடிந்ததும் `SP-Voice-Call-debug-apk` artifact-ஐ download செய்யவும்.

## முதல் முறை அமைத்தல்
1. APK install செய்யவும்.
2. App திறந்து `Spam Blocker-ஐ Activate செய்` அழுத்தவும்.
3. Android-ல் SP Voice Call-ஐ Call Screening app ஆகத் தேர்வு செய்யவும்.
4. Contacts permission கொடுக்கவும்; Unknown blocking பயன்படுத்தும்போது இது அவசியம்.
5. Unknown number blocking-ஐ தேவைக்கேற்ப ON/OFF செய்யவும்.

## Build note
Project uses Gradle 8.9-compatible Android Gradle Plugin 8.7.3 and JDK 17. GitHub runner uses installed Gradle; Android Studio may generate a Gradle wrapper when project is opened.
