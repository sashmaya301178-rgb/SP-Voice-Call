package com.spagency.voicecall

data class CallEntry(
    val number: String,
    val status: String,
    val timestamp: Long
)
