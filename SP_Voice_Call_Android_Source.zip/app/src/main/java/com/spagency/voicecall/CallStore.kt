package com.spagency.voicecall

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object CallStore {
    private const val PREFS = "sp_voice_call"
    private const val KEY_HISTORY = "history"
    private const val KEY_UNKNOWN = "block_unknown"
    private const val KEY_MANUAL = "manual_spam"

    fun add(context: Context, number: String, status: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = JSONArray(prefs.getString(KEY_HISTORY, "[]"))
        val next = JSONArray()
        next.put(JSONObject().put("number", number.ifBlank { "Private number" })
            .put("status", status).put("time", System.currentTimeMillis()))
        for (i in 0 until minOf(old.length(), 99)) next.put(old.getJSONObject(i))
        prefs.edit().putString(KEY_HISTORY, next.toString()).apply()
    }

    fun history(context: Context): List<CallEntry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_HISTORY, "[]")
        val array = JSONArray(raw)
        return (0 until array.length()).mapNotNull { i ->
            runCatching {
                val o = array.getJSONObject(i)
                CallEntry(o.optString("number"), o.optString("status"), o.optLong("time"))
            }.getOrNull()
        }
    }

    fun blockUnknown(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_UNKNOWN, false)

    fun setBlockUnknown(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_UNKNOWN, value).apply()
    }

    fun isManualSpam(context: Context, number: String): Boolean {
        val list = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_MANUAL, emptySet()) ?: emptySet()
        val normalized = normalize(number)
        return normalized.isNotBlank() && list.any { normalize(it) == normalized }
    }

    fun addManualSpam(context: Context, number: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val list = (prefs.getStringSet(KEY_MANUAL, emptySet()) ?: emptySet()).toMutableSet()
        list.add(number.trim())
        prefs.edit().putStringSet(KEY_MANUAL, list).apply()
    }

    fun manualSpam(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_MANUAL, emptySet())?.toSet() ?: emptySet()

    fun normalize(number: String): String = number.filter { it.isDigit() || it == '+' }
}
