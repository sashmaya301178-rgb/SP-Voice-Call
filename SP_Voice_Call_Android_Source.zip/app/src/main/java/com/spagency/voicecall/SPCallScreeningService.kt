package com.spagency.voicecall

import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.CallScreeningService.CallResponse
import android.provider.ContactsContract
import android.net.Uri

class SPCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        if (callDetails.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(callDetails, CallResponse.Builder().build())
            return
        }

        val handle = callDetails.handle
        val number = handle?.schemeSpecificPart.orEmpty()
        val isKnown = number.isNotBlank() && isInContacts(number)
        val is140 = number.filter { it.isDigit() }.startsWith("140")
        val isManualSpam = CallStore.isManualSpam(this, number)
        val blockUnknown = CallStore.blockUnknown(this)
        val shouldBlock = is140 || isManualSpam || (blockUnknown && !isKnown)

        if (shouldBlock) {
            val response = CallResponse.Builder()
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipCallLog(false)
                .setSkipNotification(false)
                .build()
            respondToCall(callDetails, response)
            CallStore.add(this, number, "BLOCKED")
        } else {
            respondToCall(callDetails, CallResponse.Builder().build())
            CallStore.add(this, number, "ALLOWED")
        }
    }

    private fun isInContacts(number: String): Boolean {
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(number)
            )
            contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup._ID),
                null, null, null
            )?.use { it.moveToFirst() } ?: false
        } catch (_: SecurityException) {
            false
        }
    }
}
