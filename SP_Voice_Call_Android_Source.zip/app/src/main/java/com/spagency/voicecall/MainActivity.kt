package com.spagency.voicecall

import android.app.Activity
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.Manifest
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var unknownSwitch: Switch
    private lateinit var historyBox: LinearLayout
    private var tts: TextToSpeech? = null
    private val green = 0xFF123B32.toInt()
    private val gold = 0xFFD7A84B.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        refreshHistory()
        requestContactsPermission()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) statusText.text = screeningStatus()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(0xFFF4F7F5.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            setBackgroundColor(green)
        }
        header.addView(TextView(this).apply {
            text = "SP VOICE CALL"
            textSize = 26f
            setTextColor(-1)
            setTypeface(null, 1)
        })
        header.addView(TextView(this).apply {
            text = "Smart Call Protection • Tamil Voice"
            textSize = 14f
            setTextColor(0xFFE8D9B5.toInt())
            setPadding(0, dp(5), 0, 0)
        })
        root.addView(header, matchWrap())

        statusText = TextView(this).apply {
            textSize = 16f
            setTextColor(green)
            setPadding(dp(14), dp(16), dp(14), dp(16))
            setBackgroundColor(-1)
        }
        root.addView(statusText, matchWrap())

        val activate = button("1. Spam Blocker-ஐ Activate செய்", gold)
        activate.setOnClickListener { requestScreeningRole() }
        root.addView(activate, matchWrap())

        unknownSwitch = Switch(this).apply {
            text = "Contacts-ல் இல்லாத எண்களைத் தடு"
            textSize = 15f
            setTextColor(green)
            isChecked = CallStore.blockUnknown(this@MainActivity)
            setPadding(dp(8), dp(10), dp(8), dp(10))
            setOnCheckedChangeListener { _, checked ->
                CallStore.setBlockUnknown(this@MainActivity, checked)
                Toast.makeText(this@MainActivity,
                    if (checked) "Unknown number blocking ON" else "Unknown number blocking OFF",
                    Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(unknownSwitch, matchWrap())

        val ttsButton = button("தமிழ் குரல் சோதனை", green)
        ttsButton.setOnClickListener {
            tts?.speak("வணக்கம். இது எஸ் பி ஏஜென்சி வாய்ஸ் கால் செயலியின் தமிழ் குரல் சோதனை.",
                TextToSpeech.QUEUE_FLUSH, null, "sp_tamil_test")
        }
        root.addView(ttsButton, matchWrap())

        val manualButton = button("தொலைபேசி எண்ணை Spam பட்டியலில் சேர்", green)
        manualButton.setOnClickListener { showAddSpamDialog() }
        root.addView(manualButton, matchWrap())

        val historyTitle = TextView(this).apply {
            text = "அழைப்புப் பதிவுகள்"
            textSize = 20f
            setTextColor(green)
            setTypeface(null, 1)
            setPadding(0, dp(20), 0, dp(8))
        }
        root.addView(historyTitle, matchWrap())

        historyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(-1)
        }
        root.addView(historyBox, matchWrap())

        val refresh = button("பதிவுகளை Refresh செய்", green)
        refresh.setOnClickListener { refreshHistory() }
        root.addView(refresh, matchWrap())

        root.addView(TextView(this).apply {
            text = "குறிப்பு: 140 மற்றும் நீங்கள் சேர்த்த Spam எண்களைத் தடுக்கலாம். Fraud / spam அடையாளம் காணுதல் முழுமையான உத்தரவாதம் அல்ல. தமிழ் TTS சோதனை மட்டும்; SIM அழைப்பில் AI தானாகப் பேசாது."
            textSize = 12f
            setTextColor(0xFF5B6762.toInt())
            setPadding(dp(4), dp(16), dp(4), dp(8))
        }, matchWrap())
    }

    private fun requestScreeningRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
            if (rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                Toast.makeText(this, "SP Voice Call ஏற்கனவே Activate செய்யப்பட்டுள்ளது", Toast.LENGTH_SHORT).show()
            } else {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 101)
            }
        } else {
            Toast.makeText(this, "இந்த Android சாதனத்தில் Call Screening கிடைக்கவில்லை", Toast.LENGTH_LONG).show()
        }
    }

    private fun screeningStatus(): String {
        val rm = getSystemService(RoleManager::class.java)
        val active = rm?.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) == true
        return if (active) "● Spam Protection: ACTIVE" else "● Spam Protection: NOT ACTIVE"
    }

    private fun requestContactsPermission() {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 102)
        }
    }

    private fun showAddSpamDialog() {
        val input = EditText(this).apply {
            hint = "தொலைபேசி எண்"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        AlertDialog.Builder(this)
            .setTitle("Spam எண்ணைச் சேர்")
            .setView(input)
            .setPositiveButton("சேமி") { _, _ ->
                val number = input.text.toString().trim()
                if (number.isNotBlank()) {
                    CallStore.addManualSpam(this, number)
                    Toast.makeText(this, "Spam பட்டியலில் சேர்க்கப்பட்டது", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("ரத்து", null)
            .show()
    }

    private fun refreshHistory() {
        if (!::historyBox.isInitialized) return
        historyBox.removeAllViews()
        val entries = CallStore.history(this)
        if (entries.isEmpty()) {
            historyBox.addView(TextView(this).apply {
                text = "இன்னும் அழைப்புப் பதிவுகள் இல்லை"
                setTextColor(0xFF66716B.toInt())
                setPadding(0, dp(8), 0, dp(8))
            })
        } else {
            val fmt = SimpleDateFormat("dd-MM-yyyy  hh:mm a", Locale.getDefault())
            entries.forEach { entry ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, dp(9), 0, dp(9))
                }
                row.addView(TextView(this).apply {
                    text = entry.number
                    textSize = 16f
                    setTextColor(green)
                    setTypeface(null, 1)
                })
                row.addView(TextView(this).apply {
                    text = "${entry.status}  •  ${fmt.format(Date(entry.timestamp))}"
                    textSize = 12f
                    setTextColor(if (entry.status == "BLOCKED") 0xFFB3261E.toInt() else 0xFF247A4B.toInt())
                })
                historyBox.addView(row)
                val line = View(this).apply { setBackgroundColor(0xFFE5EAE6.toInt()) }
                historyBox.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
    }

    private fun button(label: String, color: Int): Button = Button(this).apply {
        text = label
        textSize = 14f
        setTextColor(if (color == gold) green else -1)
        setBackgroundColor(color)
        setAllCaps(false)
        setPadding(dp(8), dp(6), dp(8), dp(6))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply {
        bottomMargin = dp(10)
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ta", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("ta"))
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
